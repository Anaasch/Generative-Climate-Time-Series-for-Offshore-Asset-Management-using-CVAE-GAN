import numpy as np
from simulate import SimuleTS
from scipy.stats import wasserstein_distance, ks_2samp, levene
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean
import pandas as pd


def windows(Mat, v):
    """
    Calcule la longueur des fenêtres où Mat < v (par variable si multi-colonnes).
    
    Args:
        Mat : np.ndarray (N, d)
        v   : np.ndarray ou float (seuil par variable)
    Returns:
        np.ndarray : longueurs des fenêtres détectées
    """
    Mat = np.atleast_2d(Mat)
    if Mat.shape[1] == 1:  # Cas 1 variable
        below = Mat.flatten() < v
    else:  # Cas multi-variable
        below = np.all(Mat < v, axis=1)  # toutes les variables < seuil
    # Détection transitions 0→1 et 1→0
    diff = np.diff(below.astype(int))
    start_idx = np.where(diff == 1)[0] + 1
    end_idx   = np.where(diff == -1)[0] + 1
    if below[0]:
        start_idx = np.insert(start_idx, 0, 0)
    if below[-1]:
        end_idx = np.append(end_idx, len(below))
    # Longueurs
    return (end_idx - start_idx) if len(start_idx) > 0 else np.array([])

def windowsMois(Mat, v, mois):
    """
    Calcule les durées des fenêtres (en heures) pendant lesquelles
    toutes les colonnes de Mat sont < v, uniquement pour les instants du mois donné.
    """
    Mat = np.array(Mat)
    v = np.array(v)

    if mois < 1 or mois > 12:
        raise ValueError("Le mois doit être compris entre 1 et 12.")

    # Générer un filtre binaire
    dureeMois = np.tile([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], (4, 1))
    filtre = []
    for k in range(5000):
        for j in range(12):
            heures = dureeMois[k % 4, j] * 24
            filtre.extend([1 if (j + 1) == mois else 0] * heures)
        if len(filtre) >= len(Mat):
            break
    filtre = np.array(filtre[:len(Mat)])

    # Masquage des données hors mois
    MatMasked = Mat.copy()
    MatMasked[filtre == 0, :] = 1000

    # Fenêtres où toutes les variables < seuil
    W = np.all(MatMasked < v, axis=1).astype(int)

    # Transitions entrée/sortie de fenêtres
    W_diff = np.diff(W)
    ind1 = np.where(W_diff == 1)[0] + 1
    ind2 = np.where(W_diff == -1)[0] + 1

    if len(ind1) == 0 or len(ind2) == 0:
        return np.array([])

    # Durées des fenêtres
    if ind1[0] < ind2[0]:
        N = min(len(ind1), len(ind2))
        Windows = ind2[:N] - ind1[:N]
    else:
        N = min(len(ind1), len(ind2) - 1)
        Windows = ind2[1:N+1] - ind1[:N]

    return np.array(Windows)


def generate_month_mask(length, target_month):
    """
    Génère un masque binaire (1 = le point appartient au mois cible)
    Args:
        length (int): longueur de la série temporelle (ex: 147176)
        target_month (int): mois à cibler (1 à 12)
    Returns:
        mask (ndarray bool): tableau de taille (length,)
    """
    # Jours par mois selon les années normales et bissextiles
    days_by_month = np.array([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])  # année normale
    days_by_month_leap = np.array([31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])  # année bissextile

    mask = []
    year = 0
    while len(mask) < length:
        # Alterne entre année normale et bissextile
        if year % 4 == 0:
            current_months = days_by_month_leap
        else:
            current_months = days_by_month

        for m in range(1, 13):
            hours = current_months[m - 1] * 24
            if m == target_month:
                mask.extend([1] * hours)
            else:
                mask.extend([0] * hours)

            if len(mask) >= length:
                break
        year += 1

    return np.array(mask[:length], dtype=bool)

# --- 1. Score distribution (Wasserstein 1D) ---
def score_distribution(Sim, Obs):
    Sim = np.atleast_2d(Sim)
    Obs = np.atleast_2d(Obs)
    dists = []
    for i in range(Sim.shape[1]):
        s = Sim[:, i].ravel()
        o = Obs[:, i].ravel()
        d = wasserstein_distance(s, o)
        dists.append(1 / (1 + d))
    return np.mean(dists)

def score_saisonnalite_distance(Sim, Obs):
    mois_list = range(1, 13)
    distances = []
    for mois in mois_list:
        filtre = generate_month_mask(len(Sim), mois)
        S = Sim[filtre]
        O = Obs[filtre]
        if len(S) < 10:
            continue
        for i in range(Sim.shape[1]):
            d = wasserstein_distance(S[:, i], O[:, i])
            distances.append(d)
    return 1 / (1 + np.mean(distances)) if distances else 0.0

# --- 3. Score corrélation inter-variable ---
def score_correlation_inter_variable(Sim, Obs):
    if Sim.shape[1] < 2:
        return 0.0
    corr_sim = np.corrcoef(Sim.T)
    corr_obs = np.corrcoef(Obs.T)
    mask = ~np.eye(Sim.shape[1], dtype=bool)
    diff = np.abs(corr_sim[mask] - corr_obs[mask])
    return 1 - np.mean(diff)

# --- 4. Fenêtres KS ---
def score_fenetre_ks(Sim, Obs, fen):
    """
    Applique la fenêtre multivariée une seule fois, selon toutes les variables,
    puis compare les distributions via le test de Kolmogorov–Smirnov.
    """
    wSim = windows(Sim, fen)
    wObs = windows(Obs, fen)

    wSim = np.ravel(wSim)
    wObs = np.ravel(wObs)

    if len(wObs) < 2 or len(wSim) < 2:
        return 0.0

    stat, _ = ks_2samp(wSim, wObs)
    return 1 - stat

# --- 5. Variabilité mensuelle (Levene) ---
def score_variabilite_levene(Sim, Obs, fen):
    scores = []
    for mois in range(1, 13):
        wSim = windowsMois(Sim, fen, mois)
        wObs = windowsMois(Obs, fen, mois)
        wSim = np.ravel(wSim)
        wObs = np.ravel(wObs)
        if len(wObs) < 2 or len(wSim) < 2:
            continue
        stat, _ = levene(wSim, wObs, center='median')
        scores.append(1 / (1 + stat))
    return np.mean(scores) if scores else 0.0

# --- 6. DTW robuste ---

def score_dtw(Sim, Obs, step=3):
    """
    Score DTW basé sur fastdtw avec transformation en séquence de points (index, valeur)
    pour éviter l'erreur "Input vector should be 1-D".
    """
    scores = []
    for i in range(Sim.shape[1]):
        s = Sim[::step, i].astype(float).flatten()
        o = Obs[::step, i].astype(float).flatten()

        # Si trop court
        if len(s) < 2 or len(o) < 2:
            scores.append(0.0)
            continue

        # Transformation en points (index, valeur)
        s_points = [(idx, val) for idx, val in enumerate(s)]
        o_points = [(idx, val) for idx, val in enumerate(o)]

        d, _ = fastdtw(s_points, o_points, dist=euclidean)
        scores.append(1 / (1 + d))

    return np.mean(scores) if scores else 0.0

# --- 7. Score global ---
def compute_final_score(Sim, Obs, fen, weights=None):
    if weights is None:
        weights = {
            "distribution": 0.2,
            "fenetre_ks": 0.2,
            "saisonnalite": 0.2,
            "variabilite": 0.2,
            "correlation_inter": 0.2
          #  "dtw": 0.20
        }
    scores = {
        "distribution": score_distribution(Sim, Obs),
        "fenetre_ks": score_fenetre_ks(Sim, Obs, fen),
        "saisonnalite": score_saisonnalite_distance(Sim, Obs),
        "variabilite": score_variabilite_levene(Sim, Obs, fen),
        "correlation_inter": score_correlation_inter_variable(Sim, Obs),
       # "dtw": score_dtw(Sim, Obs)
    }
    return sum(weights[k] * scores[k] for k in scores), scores

# --- 8. Évaluation multi-scénarios ---
def evaluate_multiple_scenarios(vae_model, 
                                 X_input_test, 
                                 Y_target_test, 
                                 seasonFreq, 
                                 Min_list, 
                                 Max_list, 
                                 nVar,
                                 fen,
                                 n_scenarios=10, 
                                 GAUSSIAN_STD=1.0):
    
    results = []
    lagO_dim = Y_target_test.shape[1]
    T = lagO_dim // nVar # taille de la séquence
    Y_target_real = np.empty_like(Y_target_test)

    # Dé-normalisation
    for i in range(nVar):
        idx = np.arange(i, lagO_dim, nVar)
        Y_target_real[:, idx] = 0.5 * (Y_target_test[:, idx] + 1) * (Max_list[i] - Min_list[i]) + Min_list[i]  # shape (147176, 94)

    # ✅ Reconstruit proprement sans duplication
    Obs_full_list = []
    for i, row in enumerate(Y_target_real):
        seq = row.reshape(T, nVar)
        if i == 0:
            Obs_full_list.extend(seq.tolist())  # toute la première
        else:
            Obs_full_list.append(seq[-1].tolist())
    Obs_full = np.array(Obs_full_list)

    for scenario_id in range(n_scenarios):
        Sim_real, _ = SimuleTS(
                vae_model=vae_model,
                X_input=X_input_test,
                seasonFreq=seasonFreq,
                Min_list=Min_list,
                Max_list=Max_list,
                nVar=nVar,
                GAUSSIAN_STD=GAUSSIAN_STD
            )
        Sim_full = Sim_real.reshape(-1, nVar)

        min_len = min(Sim_full.shape[0], Obs_full.shape[0])

        try:
            score_total, detailed_scores = compute_final_score(Sim_full[:min_len], Obs_full[:min_len], fen)
        except Exception as e:
            print(f"⚠️ Erreur scénario {scenario_id}: {e}")
            score_total = np.nan
            detailed_scores = {k: np.nan for k in [
                "distribution", "fenetre_ks", "saisonnalite",
                "variabilite", "correlation_inter", "dtw"
            ]}
        results.append({
            "scenario_id": scenario_id,
            "simulated_series": Sim_full[:min_len],
            "score_global": score_total,
            **detailed_scores
        })

    df_scores = pd.DataFrame(results)
    return df_scores.sort_values(by="scenario_id").reset_index(drop=True)