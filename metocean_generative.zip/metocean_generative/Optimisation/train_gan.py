import sys
import os
import random
import numpy as np
import tensorflow as tf
import traceback

# -----------------------------
# Réglages TensorFlow et seed
# -----------------------------
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
tf.get_logger().setLevel('ERROR')

# Seed pour reproductibilité
seed_value = 42
os.environ['PYTHONHASHSEED'] = str(seed_value)
random.seed(seed_value)
np.random.seed(seed_value)
tf.random.set_seed(seed_value)

# -----------------------------
# Imports de ton projet
# -----------------------------
from data_preparation import load_and_prepare_data
from GAN_model import train_gan_with_params
from custom_score_gan import evaluate_multiple_scenarios

# -----------------------------
# Paramètres optimaux retournés par NOMAD
# -----------------------------
params = {
    "nVar": 2,
    "Lag": 8,
    "LagO": 47,
    "seasonFreq": [24, 8760],
    "z_dim": 32,
    "nb_layers": 3,
    "activation": "leakyrelu",
    "units_gen": 256,
    "units_disc": 256,
    "gp_weight": 10.0,
    "n_critic": 5,
    "l1_weight": 10.0,
    "g_optimizer_name": "adam",
    "d_optimizer_name": "adam",
    "lr_g": 0.0001,
    "lr_d": 0.0001,
    "beta_1": 0.5,
    "beta_2": 0.9,
    "epochs": 40,
    "batch_size": 128,
    "z_std": 1.0
}

try:
    # -----------------------------
    # Chargement des données
    # -----------------------------
    X_train, Y_train, X_test, Y_test, Min_list, Max_list, fen = load_and_prepare_data(
        lag=params["Lag"], lag0=params["LagO"]
    )

    # -----------------------------
    # Entraînement GAN
    # -----------------------------
    gan_model, _ = train_gan_with_params(
        X_train, Y_train,
        X_test, Y_test,
        params
    )

    # -----------------------------
    # Sauvegarde du modèle
    # -----------------------------
    model_path = "gan_model_saved.h5"
    gan_model.save(model_path)
    print(f"Model saved at {model_path}")

    # -----------------------------
    # Évaluation
    # -----------------------------
    df_scores = evaluate_multiple_scenarios(
        gan_model=gan_model,
        X_input_test=X_test,
        Y_target_test=Y_test,
        seasonFreq=params['seasonFreq'],
        Min_list=Min_list,
        Max_list=Max_list,
        nVar=params['nVar'],
        fen=fen,
        n_scenarios=1,
        GAUSSIAN_STD=params['z_std']
    )

    print("Training and evaluation completed successfully.")
    if "score_global" in df_scores.columns:
        print("Mean score_global:", df_scores["score_global"].mean())

except Exception as e:
    with open("debug_train_gan.log", "a") as f:
        f.write("Exception during GAN training:\n")
        f.write(traceback.format_exc())
    print("An error occurred. Check debug_train_gan.log for details.")