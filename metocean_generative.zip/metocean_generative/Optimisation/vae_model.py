import tensorflow as tf
from tensorflow.keras import layers, Model, Input
import numpy as np

class VAEModel(Model):
    def __init__(self, encoder, decoder, n_season=2, beta=0.02):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.n_season = n_season
        self.beta = tf.Variable(beta, trainable=False, dtype=tf.float32)
        self.total_loss_tracker = tf.keras.metrics.Mean(name="loss")
        self.reconstruction_loss_tracker = tf.keras.metrics.Mean(name="reconstruction_loss")
        self.kl_loss_tracker = tf.keras.metrics.Mean(name="kl_loss")

    def compile(self, optimizer):
        super().compile()
        self.optimizer = optimizer

    @property
    def metrics(self):
        return [
            self.total_loss_tracker,
            self.reconstruction_loss_tracker,
            self.kl_loss_tracker,
        ]

    def train_step(self, data):
        X, y_true = data
        season_inputs = list(X[:self.n_season])
        lag_input = X[self.n_season]
        lagO_input = X[self.n_season + 1]
        
        with tf.GradientTape() as tape:
            z, z_mean, z_log_std = self.encoder(season_inputs + [lag_input, lagO_input], training=True)
            y_pred = self.decoder(season_inputs + [lag_input, z], training=True)
            recon_loss = tf.reduce_mean(tf.square(y_true - y_pred))
            z_log_var = 2 * z_log_std
            kl_vector = -0.5 * (1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var))
            kl_loss = tf.reduce_mean(tf.reduce_sum(kl_vector, axis=1))
            total_loss = recon_loss + self.beta * kl_loss

        grads = tape.gradient(total_loss, self.trainable_weights)
        self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
        self.total_loss_tracker.update_state(total_loss)
        self.reconstruction_loss_tracker.update_state(recon_loss)
        self.kl_loss_tracker.update_state(kl_loss)
        
        return {
            "loss": self.total_loss_tracker.result(),
            "reconstruction_loss": self.reconstruction_loss_tracker.result(),
            "kl_loss": self.kl_loss_tracker.result(),
        }

    def test_step(self, data):
        X, y_true = data
        season_inputs = list(X[:self.n_season])
        lag_input = X[self.n_season]
        lagO_input = X[self.n_season + 1]
        z, z_mean, z_log_std = self.encoder(season_inputs + [lag_input, lagO_input], training=False)
        y_pred = self.decoder(season_inputs + [lag_input, z], training=False)
        recon_loss = tf.reduce_mean(tf.square(y_true - y_pred))
        z_log_var = 2 * z_log_std
        kl_vector = -0.5 * (1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var))
        kl_loss = tf.reduce_mean(tf.reduce_sum(kl_vector, axis=1))
        total_loss = recon_loss + self.beta * kl_loss
        self.total_loss_tracker.update_state(total_loss)
        self.reconstruction_loss_tracker.update_state(recon_loss)
        self.kl_loss_tracker.update_state(kl_loss)
        return {
            "loss": self.total_loss_tracker.result(),
            "reconstruction_loss": self.reconstruction_loss_tracker.result(),
            "kl_loss": self.kl_loss_tracker.result(),
        }

class BetaScheduler(tf.keras.callbacks.Callback):
    def __init__(self, vae_model, max_beta=0.0001, warmup_epochs=30, cyclical=False, cycle_length=5):
        super().__init__()
        self.vae_model = vae_model
        self.max_beta = max_beta
        self.warmup_epochs = warmup_epochs
        self.cyclical = cyclical
        self.cycle_length = cycle_length

    def on_epoch_begin(self, epoch, logs=None):
        if self.cyclical:
            cycle_pos = epoch % self.cycle_length
            new_beta = self.max_beta * (cycle_pos / self.cycle_length)
        else:
            new_beta = min(self.max_beta, epoch / self.warmup_epochs * self.max_beta)
        self.vae_model.beta.assign(new_beta)

def build_dense_layers(x, nb_layers, units, activation):
    for _ in range(nb_layers):
        x = layers.Dense(units)(x)
        if activation == 'leakyrelu':
            x = layers.LeakyReLU(negative_slope=0.2)(x)
        else:
            x = layers.Activation(activation)(x)
    return x

def build_encoder(nVar, Lag, LagO, Latency, seasonFreq, nb_layers=2, units=64, activation='relu'):
    season_inputs = [Input(shape=(2,), name=f"season_input_{i}") for i in range(len(seasonFreq))]
    lag_input = Input(shape=(nVar * Lag,), name="lag_input")
    lagO_input = Input(shape=(nVar * LagO,), name="lagO_input")
    concat = layers.Concatenate(axis=-1)(season_inputs + [lag_input, lagO_input])
    x = build_dense_layers(concat, nb_layers=nb_layers, units=units * nVar, activation=activation)
    z_params = layers.Dense(2 * Latency, name="vae_encoder_out")(x)
    z_mean = layers.Lambda(lambda t: t[:, :Latency], name="z_mean")(z_params)
    z_log_std = layers.Lambda(lambda t: t[:, Latency:], name="z_log_std")(z_params)

    def sampling(args):
        z_mean, z_log_std = args
        z_std = tf.exp(z_log_std)
        epsilon = tf.random.normal(shape=tf.shape(z_mean), mean=0.0, stddev=1.0)
        return z_mean + z_std * epsilon

    z = layers.Lambda(sampling, name="z")([z_mean, z_log_std])
    encoder = Model(inputs=season_inputs + [lag_input, lagO_input], outputs=[z, z_mean, z_log_std], name="encoder")
    return encoder

def build_decoder(nVar, Lag, Latency, LagO, seasonFreq, nb_layers=2, units=94, activation='relu'):
    season_inputs = [Input(shape=(2,), name=f"dec_season_input_{i}") for i in range(len(seasonFreq))]
    lag_input = Input(shape=(nVar * Lag,), name="dec_lag_input")
    z_input = Input(shape=(Latency,), name="z_input")
    concat = layers.Concatenate(axis=-1)(season_inputs + [lag_input, z_input])
    x = build_dense_layers(concat, nb_layers=nb_layers, units=units, activation=activation)
    reconstruction = layers.Dense(nVar * LagO, activation='tanh', name="reconstruction")(x)
    decoder = Model(inputs=season_inputs + [lag_input, z_input], outputs=reconstruction, name="decoder")
    return decoder

def build_encoder_decoder(nVar=2, Lag=4, LagO=44, latent_dim=10, seasonFreq=[24, 8760], nb_layers=2, activation='relu', units_encoder=64, units_decoder=94):
    Latency = 2 * (latent_dim * nVar + len(seasonFreq))
    encoder = build_encoder(nVar=nVar, Lag=Lag, LagO=LagO, Latency=Latency, seasonFreq=seasonFreq, nb_layers=nb_layers, units=units_encoder, activation=activation)
    decoder = build_decoder(nVar=nVar, Lag=Lag, LagO=LagO, Latency=Latency, seasonFreq=seasonFreq, nb_layers=nb_layers, units=units_decoder, activation=activation)
    return encoder, decoder

# Optimiseur utilitaire
def get_optimizer(name='adam', learning_rate=1e-3):
    name = name.lower()
    if name == 'adam':
        return tf.keras.optimizers.Adam(learning_rate=learning_rate)
    elif name == 'rmsprop':
        return tf.keras.optimizers.RMSprop(learning_rate=learning_rate)
    elif name == 'sgd':
        return tf.keras.optimizers.SGD(learning_rate=learning_rate)
    else:
        raise ValueError(f"Optimiseur '{name}' non supporté")

# Exemple complet de pipeline d'entraînement avec grid search simplifié
def train_vae_with_params(X_train, Y_train, X_test, Y_test, params):
    """
    params = dict avec clés:
        - nVar, Lag, LagO, latent_dim
        - nb_layers
        - activation (ex: 'relu', 'leakyrelu', 'tanh')
        - units_encoder, units_decoder
        - optimizer_name ('adam', 'rmsprop', 'sgd')
        - learning_rate
        - beta_max, beta_warmup_epochs
        - epochs, batch_size
    """
    print(f"Training with params: {params}")
    
    encoder, decoder = build_encoder_decoder(
        nVar=params.get('nVar', 2),
        Lag=params.get('Lag', 8),
        LagO=params.get('LagO', 47),
        latent_dim=params.get('latent_dim', 5),
        seasonFreq=params.get('seasonFreq', [24, 8760]),
        nb_layers=params.get('nb_layers', 3),
        activation=params.get('activation', 'leakyrelu'),
        units_encoder=params.get('units_encoder', 300),
        units_decoder=params.get('units_decoder', 512)
    )
    
    vae = VAEModel(encoder, decoder, n_season=len(params.get('seasonFreq', [24, 8760])), beta=0.0)
    
    optimizer = get_optimizer(name=params.get('optimizer_name', 'adam'), learning_rate=params.get('learning_rate', 1e-3))
    vae.compile(optimizer=optimizer)
    
    beta_callback = BetaScheduler(
        vae_model=vae,
        max_beta=params.get('beta_max', 0.0001),
        warmup_epochs=params.get('beta_warmup_epochs', 30),
        cyclical=params.get('beta_cyclical', False),
        cycle_length=params.get('beta_cycle_length', 5)
    )
    
    history = vae.fit(
        x=X_train,
        y=Y_train,
        validation_data=(X_test, Y_test),
        epochs=params.get('epochs', 50),
        batch_size=params.get('batch_size', 32),
        callbacks=[beta_callback],
        verbose=2,
    )
    
    return vae, history
