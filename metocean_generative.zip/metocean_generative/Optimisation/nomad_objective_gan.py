import sys
import os
import traceback
import random
import numpy as np
import tensorflow as tf

# Déterminisme
os.environ['PYTHONHASHSEED'] = '42'
os.environ['TF_DETERMINISTIC_OPS'] = '1'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.get_logger().setLevel('ERROR')

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

from data_preparation import load_and_prepare_data
from GAN_model import train_gan_with_params
from custom_score_gan import evaluate_multiple_scenarios

def evaluate_model(params):
    try:
        X_train, Y_train, X_test, Y_test, Min_list, Max_list, fen = load_and_prepare_data(
            lag=params["Lag"], lag0=params["LagO"]
        )
        gan_model, _ = train_gan_with_params(
            X_train, Y_train, X_test, Y_test, params
        )
        df_scores = evaluate_multiple_scenarios(
            gan_model=gan_model,  # simulate_gan.py utilise sample_forecast
            X_input_test=X_test,
            Y_target_test=Y_test,
            seasonFreq=params['seasonFreq'],
            Min_list=Min_list,
            Max_list=Max_list,
            nVar=params['nVar'],
            fen=fen,
            n_scenarios=1,
            GAUSSIAN_STD=params.get('z_std', 1.0)
        )
        if "score_global" not in df_scores.columns or df_scores["score_global"].empty:
            raise ValueError("score_global missing or empty in df_scores")
        mean_score = df_scores["score_global"].mean()
        if not np.isfinite(mean_score):
            raise ValueError("mean_score is not finite")
        obj = -mean_score
    except Exception as e:
        with open("debug_args_gan.log", "a", encoding="utf-8") as f:
            f.write(f"Exception in evaluate_model: {str(e)}\n")
            f.write(traceback.format_exc())
            f.write("Params: " + str(params) + "\n")
        obj = 1e6
    return obj

if __name__ == "__main__":
    if len(sys.argv) != 16:
        print(1e6)
        sys.exit(0)

    try:
        z_dim = int(round(float(sys.argv[1])))
        nb_layers = int(round(float(sys.argv[2])))
        act_idx = int(round(float(sys.argv[3])))
        units_gen = int(round(float(sys.argv[4])))
        units_disc = int(round(float(sys.argv[5])))
        n_critic = int(round(float(sys.argv[6])))
        gp_weight = float(sys.argv[7])
        l1_weight = float(sys.argv[8])
        beta_1 = float(sys.argv[9])
        beta_2 = float(sys.argv[10])
        log_lr_g = float(sys.argv[11])
        log_lr_d = float(sys.argv[12])
        batch_size = int(round(float(sys.argv[13])))
        Lag = int(round(float(sys.argv[14])))
        LagO = int(round(float(sys.argv[15])))
    except Exception as e:
        with open("debug_args_gan.log", "a", encoding="utf-8") as f:
            f.write(f"Exception parsing args: {str(e)}\n")
            f.write(traceback.format_exc())
            f.write("Arguments reçus : " + str(sys.argv) + "\n")
        print(1e6)
        sys.exit(0)

    activation_list = ['relu', 'tanh', 'leakyrelu']
    activation = activation_list[act_idx] if 0 <= act_idx < len(activation_list) else 'leakyrelu'

    params = {
        "nVar": 2,
        "Lag": Lag,
        "LagO": LagO,
        "seasonFreq": [24, 8760],
        "z_dim": z_dim,
        "nb_layers": nb_layers,
        "activation": activation,
        "units_gen": units_gen,
        "units_disc": units_disc,
        "gp_weight": gp_weight,
        "n_critic": n_critic,
        "l1_weight": l1_weight,
        "g_optimizer_name": "adam",
        "d_optimizer_name": "adam",
        "lr_g": 10 ** log_lr_g,
        "lr_d": 10 ** log_lr_d,
        "beta_1": beta_1,
        "beta_2": beta_2,
        "epochs": 30,
        "batch_size": batch_size,
        "z_std": 1.0,
    }

    score = evaluate_model(params)
    if not isinstance(score, (float, int)) or not np.isfinite(score):
        score = 1e6

    try:
        with open("log_nomad_results_gan.csv", "a", encoding="utf-8") as f:
            f.write(
                f"{z_dim},{nb_layers},{activation},{units_gen},{units_disc},"
                f"{n_critic},{gp_weight},{l1_weight},{beta_1},{beta_2},"
                f"{10**log_lr_g},{10**log_lr_d},{batch_size},{Lag},{LagO},{score}\n"
            )
    except Exception as e:
        with open("debug_args_gan.log", "a", encoding="utf-8") as f:
            f.write(f"Exception writing log: {str(e)}\n")

    print(score)
    sys.stdout.flush()