import matplotlib.pyplot as plt
import numpy as np

def windows(Mat, v):
    """
    Calcule la longueur des fenêtres où Mat < v (par variable si multi-colonnes).
    
    Args:
        Mat : np.ndarray (N, d)
        v   : np.ndarray ou float (seuil par variable)
    Returns:
        np.ndarray : longueurs des fenêtres détectées
    """
    Mat = np.atleast_2d(Mat)
    if Mat.shape[1] == 1:  # Cas 1 variable
        below = Mat.flatten() < v
    else:  # Cas multi-variable
        below = np.all(Mat < v, axis=1)  # toutes les variables < seuil
    # Détection transitions 0→1 et 1→0
    diff = np.diff(below.astype(int))
    start_idx = np.where(diff == 1)[0] + 1
    end_idx   = np.where(diff == -1)[0] + 1
    if below[0]:
        start_idx = np.insert(start_idx, 0, 0)
    if below[-1]:
        end_idx = np.append(end_idx, len(below))
    # Longueurs
    return (end_idx - start_idx) if len(start_idx) > 0 else np.array([])

def TraceFenetres(Sim, Obs, N=300, fig=None, mat=None, pos=None):
    """
    Compare les durées moyennes des fenêtres entre simulation et observation.
    
    Args:
        Sim (ndarray): Simulation (N, d)
        Obs (ndarray): Observation (N, d)
        N (int): Nombre de seuils aléatoires à tester
    """
    Ndata = min(len(Sim), len(Obs))
    Nvar  = Obs.shape[1]

    mSim, mReel, etSim, etReel, nSim, nReel = [], [], [], [], [], []
    skipped = 0

    # bornes de seuil
    Max = np.percentile(Obs, 99, axis=0)
    Min = np.percentile(Obs,  1, axis=0)

    for k in range(N):
        # seuil vectoriel aléatoire (comme MATLAB rand(1,Nvar).*(Max-Min)+Min)
        fen = np.random.rand(Nvar) * (Max - Min) + Min
        
        wSim = windows(Sim, fen)
        wReel = windows(Obs, fen)

        if len(wSim) == 0 or len(wReel) == 0:
            skipped += 1
            continue

        mSim.append(np.mean(wSim))
        mReel.append(np.mean(wReel))
        etSim.append(np.std(wSim))
        etReel.append(np.std(wReel))
        nSim.append(len(wSim))
        nReel.append(len(wReel))

    print(f"{skipped} cas ignorés sur {N}")

    # convertir en numpy
    mSim, mReel = np.array(mSim), np.array(mReel)
    etSim, etReel, nSim, nReel = map(np.array, (etSim, etReel, nSim, nReel))

    # plot
    if fig is not None and mat is not None and pos is not None:
        plt.figure(fig.number)
        plt.subplot(mat[0], mat[1], pos)
    else:
        fig = plt.figure(figsize=(8, 6))

    plt.loglog(mReel, mSim, 'r+', label='moyennes')
    for k in range(len(mSim)):
        x_err = 1.96 * etReel[k] / np.sqrt(nReel[k])
        y_err = 1.96 * etSim[k] / np.sqrt(nSim[k])
        plt.fill(
            [mReel[k]-x_err, mReel[k]-x_err, mReel[k]+x_err, mReel[k]+x_err],
            [mSim[k]+y_err, mSim[k]-y_err, mSim[k]-y_err, mSim[k]+y_err],
            color=(0.8, 0.8, 0.8), alpha=0.5, edgecolor='none'
        )

    diag_lim = [1, 10**np.ceil(np.log10(max(np.max(mReel), np.max(mSim))))]
    plt.plot(diag_lim, diag_lim, 'r-', label='y=x')
    plt.grid(True, which="both", linestyle="--", linewidth=0.5)
    plt.xlabel("Durée Moyenne Fenêtre - Observation")
    plt.ylabel("Durée Moyenne Fenêtre - Simulation")
    plt.title(f"Comparaison Observation/Simulation ({N} seuils)")
    plt.legend()

    # erreur relative moyenne
    valid = mReel > 0
    m = np.mean(np.abs(mSim[valid] - mReel[valid]) / mReel[valid]) if np.any(valid) else np.nan
    return m, fig


def TraceScatterPlot(Sim, Obs=None, nomVar=["Wind Speed", "Wave Height"], fig=None):
    """
    Trace une matrice de scatter plots (simulation vs simulation)
    et (observation vs observation) si Obs est fourni.
    
    Args:
        Sim (ndarray): Simulation (N, d)
        Obs (ndarray, optionnel): Observation (N, d)
        nomVar (list[str], optionnel): Noms des variables
        fig (matplotlib.figure.Figure, optionnel): figure existante
    
    Returns:
        fig (matplotlib.figure.Figure)
    """
    Ndata, Nvar = Sim.shape
    has_obs = Obs is not None

    # Figure
    if fig is None:
        fig = plt.figure(figsize=(4 * (2 if has_obs else 1) * Nvar, 4 * Nvar))

    # Grille dynamique
    ncols = 2 * Nvar if has_obs else Nvar
    axes = fig.subplots(nrows=Nvar, ncols=ncols, squeeze=False)

    for i in range(Nvar):
        for j in range(Nvar):
            # --- Simulation ---
            ax_sim = axes[i, j * (2 if has_obs else 1)]
            ax_sim.plot(Sim[:, i], Sim[:, j], 'r.', markersize=1)
            ax_sim.grid(True)

            xi = nomVar[i] if nomVar else f"var {i+1}"
            xj = nomVar[j] if nomVar else f"var {j+1}"
            ax_sim.set_xlabel(f"Sim: {xi}")
            ax_sim.set_ylabel(f"Sim: {xj}")

            # Axes synchronisés
            x_min = np.min(Sim[:, i])
            x_max = np.max(Sim[:, i])
            y_min = np.min(Sim[:, j])
            y_max = np.max(Sim[:, j])

            if has_obs:
                x_min = min(x_min, np.min(Obs[:, i]))
                x_max = max(x_max, np.max(Obs[:, i]))
                y_min = min(y_min, np.min(Obs[:, j]))
                y_max = max(y_max, np.max(Obs[:, j]))

            ax_sim.set_xlim(x_min, x_max)
            ax_sim.set_ylim(y_min, y_max)

            # --- Observation ---
            if has_obs:
                ax_obs = axes[i, j * 2 + 1]
                ax_obs.plot(Obs[:, i], Obs[:, j], 'b.', markersize=1)
                ax_obs.grid(True)
                ax_obs.set_xlabel(f"Obs: {xi}")
                ax_obs.set_ylabel(f"Obs: {xj}")
                ax_obs.set_xlim(x_min, x_max)
                ax_obs.set_ylim(y_min, y_max)

    plt.tight_layout()
    return fig


def TraceCDFSim(Sim, Obs=None, couleurs=('r', 'b'), titres=None, pos=None, num=None):
    """
    Trace la CDF de Sim seule (comme MATLAB) ou la CDF de Sim vs Obs si Obs est fourni.

    Args:
        Sim: ndarray (T, nVar)
        Obs: ndarray optionnel (T, nVar)
        couleurs: tuple (couleur Sim, couleur Obs)
        titres: liste des titres des variables
        pos: tuple (nrows, ncols, index) pour subplot
        num: un nombre optionnel à annoter sur un point aléatoire
    """
    Sim = np.atleast_2d(Sim)
    if Sim.shape[0] == 1:
        Sim = Sim.T

    S, nVar = Sim.shape
    y = np.linspace(1/S, 1, S)

    for k in range(nVar):
        if pos is not None and len(pos) == 3:
            plt.subplot(pos[0], pos[1], pos[2])
        else:
            plt.figure(figsize=(6, 4))

        sim_sorted = np.sort(Sim[:, k])
        plt.plot(sim_sorted, y, color=couleurs[0], label="Simulation")

        if Obs is not None:
            obs_sorted = np.sort(Obs[:, k])
            plt.plot(obs_sorted, y, color=couleurs[1], label="Observation")

        if num is not None:
            idx = int(np.ceil(np.random.rand() * len(sim_sorted))) - 1
            plt.text(sim_sorted[idx], y[idx], str(num))

        plt.grid(True)
        plt.xlabel("Valeurs")
        plt.ylabel("CDF")
        titre = titres[k] if titres is not None and k < len(titres) else f"Variable {k+1}"
        plt.title(f"CDF - {titre}")
        if Obs is not None:
            plt.legend()
        plt.tight_layout()

    plt.show()


def windowsMois(Mat, v, mois):
    """
    Calcule les durées des fenêtres (en heures) pendant lesquelles
    toutes les colonnes de Mat sont < v, uniquement pour les instants du mois donné.
    """
    Mat = np.array(Mat)
    v = np.array(v)

    if mois < 1 or mois > 12:
        raise ValueError("Le mois doit être compris entre 1 et 12.")

    # Générer un filtre binaire
    dureeMois = np.tile([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], (4, 1))
    filtre = []
    for k in range(5000):
        for j in range(12):
            heures = dureeMois[k % 4, j] * 24
            filtre.extend([1 if (j + 1) == mois else 0] * heures)
        if len(filtre) >= len(Mat):
            break
    filtre = np.array(filtre[:len(Mat)])

    # Masquage des données hors mois
    MatMasked = Mat.copy()
    MatMasked[filtre == 0, :] = 1000

    # Fenêtres où toutes les variables < seuil
    W = np.all(MatMasked < v, axis=1).astype(int)

    # Transitions entrée/sortie de fenêtres
    W_diff = np.diff(W)
    ind1 = np.where(W_diff == 1)[0] + 1
    ind2 = np.where(W_diff == -1)[0] + 1

    if len(ind1) == 0 or len(ind2) == 0:
        return np.array([])

    # Durées des fenêtres
    if ind1[0] < ind2[0]:
        N = min(len(ind1), len(ind2))
        Windows = ind2[:N] - ind1[:N]
    else:
        N = min(len(ind1), len(ind2) - 1)
        Windows = ind2[1:N+1] - ind1[:N]

    return np.array(Windows)


def TraceMensuelFenetre(Sim, Obs, fen, fig=None):
    """
    Compare la durée moyenne des fenêtres mois par mois entre Simulation et Observation.

    Args:
        Sim (ndarray): Simulation (n, d)
        Obs (ndarray): Observation (n, d)
        fen (list or array): seuils par variable
        fig (Figure): figure matplotlib existante (facultatif)

    Returns:
        m (float): erreur moyenne relative entre simulation et observation
        wSim (list): fenêtres simulées par mois
        wObs (list): fenêtres observées par mois
    """
    work = np.zeros((2, 12))
    conf = np.zeros((2, 12))
    taille = np.zeros((2, 12), dtype=int)
    wSim, wObs = [], []

    for k in range(1, 13):
        # Simulation
        w = windowsMois(Sim, fen, k)
        wSim.append(w)
        if len(w) > 0:
            work[0, k-1] = np.mean(w)
            conf[0, k-1] = 1.96 * np.std(w) / np.sqrt(len(w))
            taille[0, k-1] = len(w)

        # Observation
        w = windowsMois(Obs, fen, k)
        wObs.append(w)
        if len(w) > 0:
            work[1, k-1] = np.mean(w)
            conf[1, k-1] = 1.96 * np.std(w) / np.sqrt(len(w))
            taille[1, k-1] = len(w)

    # Affichage
    if fig is not None:
        plt.figure(fig.number)
    else:
        plt.figure(figsize=(10, 6))

    months = np.arange(1, 13)
    width = 0.4

    plt.bar(months - width/2, work[0, :], width=width, label='Simulation', color='cornflowerblue')
    plt.bar(months + width/2, work[1, :], width=width, label='Observation', color='orange')

    plt.errorbar(months - width/2, work[0, :], yerr=conf[0, :], fmt='none', ecolor='black', capsize=4)
    plt.errorbar(months + width/2, work[1, :], yerr=conf[1, :], fmt='none', ecolor='black', capsize=4)

    # Erreur relative moyenne
    rel_errors = np.abs(work[0, :] - work[1, :]) / np.where(work[1, :] != 0, work[1, :], np.nan)
    m = np.nanmean(rel_errors)

    plt.grid(True, linestyle='--', alpha=0.6)
    plt.xlabel('Mois')
    plt.ylabel(f'Durée moyenne des fenêtres (h) - seuils = {fen}')
    plt.title(f'Durée moyenne mensuelle des fenêtres\nSimu: {np.mean(work[0,:]):.2f}h, Obs: {np.mean(work[1,:]):.2f}h')
    plt.xticks(months)
    plt.legend()
    plt.tight_layout()
    plt.show()

    return m, wSim, wObs




def dWas(Sim, Obs):
    """
    Distance de Wasserstein d'ordre 2 entre deux distributions.
    """
    Sim = np.array(Sim)
    Obs = np.array(Obs)

    min_len = min(len(Sim), len(Obs))
    Sim_sorted = np.sort(Sim[:min_len])
    Obs_sorted = np.sort(Obs[:min_len])

    return np.sqrt(np.mean((Sim_sorted - Obs_sorted) ** 2))

def TraceRepartitionFenetreCont(Sim, Obs, fen, fig=None, mat=(1, 1), pos=1):
    """
    Trace la fonction de répartition cumulée des longueurs de fenêtres
    où toutes les variables sont < fen (par variable).
    
    Args:
        Sim (ndarray): Simulation (N, nVar)
        Obs (ndarray): Observation (N, nVar)
        fen (list or ndarray): Seuils par variable (nVar,)
        fig (Figure): Figure existante (facultatif)
        mat (tuple): (rows, cols) pour subplot
        pos (int): index du subplot

    Returns:
        fig (Figure)
    """
    Sim = np.atleast_2d(Sim)
    Obs = np.atleast_2d(Obs)
    fen = np.array(fen)

    # Vérification dimensions
    if Sim.shape[1] != Obs.shape[1] or len(fen) != Sim.shape[1]:
        raise ValueError("Dimensions incohérentes entre Sim, Obs et fen")

    # Détecter fenêtres pour chaque série
    wSim = windows(Sim, fen)
    wObs = windows(Obs, fen)

    print(f"Nb fenêtres - Simulation: {len(wSim)}, Observation: {len(wObs)}")

    # Gestion du cas sans fenêtres
    if len(wSim) == 0 or len(wObs) == 0:
        if fig is not None:
            plt.figure(fig.number)
            plt.subplot(mat[0], mat[1], pos)
        else:
            fig = plt.figure()
        plt.text(0.5, 0.5, "Aucune fenêtre détectée", ha='center', va='center')
        plt.axis('off')
        return fig

    # CDFs
    wSim_sorted = np.sort(wSim)
    wObs_sorted = np.sort(wObs)
    cdfSim = np.linspace(1 / len(wSim), 1, len(wSim))
    cdfObs = np.linspace(1 / len(wObs), 1, len(wObs))

    # Plot
    if fig is not None:
        plt.figure(fig.number)
        plt.subplot(mat[0], mat[1], pos)
    else:
        fig = plt.figure()

    plt.semilogx(wSim_sorted, cdfSim, 'r--', label='Simulation')
    plt.semilogx(wObs_sorted, cdfObs, 'b--', label='Observation')

    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.xlabel("Durée fenêtre (h)")
    plt.ylabel("Fonction de répartition")
    plt.title(f"Moy. Sim: {np.mean(wSim):.2f}, Moy. Obs: {np.mean(wObs):.2f}, dWas: {dWas(wSim, wObs):.2f}")
    plt.legend()
    plt.tight_layout()

    return fig

def simulate_ts_report_flexible(SampleRef, SimReel, instance_idx=0, fen=None, variable_names=None):
    """
    Gère automatiquement les fonctions mono-instance et globales pour générer un rapport combiné.

    Args:
        SampleRef (ndarray): Observations globales (T, d)
        SimReel (ndarray): Simulations globales (T, d)
        instance_idx (int): Index de l'instance à analyser pour la partie mono-instance
        fen (list or None): Seuils (par défaut = médiane sur l'instance)
        variable_names (list or None): Noms des variables
    """
    # Par défaut, noms de variables
    if variable_names is None:
        variable_names = ["Wind Speed", "Wave Height"]

    # Si aucun seuil fourni → médiane des observations réelles
    if fen is None:
        fen = [np.median(SampleRef[:, 0]), np.median(SampleRef[:, 1])]

    # --- Mono-instance ---
    print("▶ Trace CDFs pour l'instance sélectionnée")
    TraceCDFSim(SimReel[:, [0]], SampleRef[:, [0]], titres=["Wind Speed"])
    TraceCDFSim(SimReel[:, [1]], SampleRef[:, [1]], titres=["Wave Height"])

    print("▶ Trace de la fonction de répartition (instance complète)")
    TraceRepartitionFenetreCont(SimReel[:, [0, 1]], SampleRef[:, [0, 1]], fen)

    print("▶ Windows mois pour l'instance sélectionnée")
    for mois in range(1, 13):
        fenêtres = windowsMois(SimReel[:, [0, 1]], fen, mois)
        print(f"Mois {mois:02d} — {len(fenêtres)} fenêtres : {fenêtres}")

    # --- Global ---
    print("▶ Trace scatter global")
    TraceScatterPlot(SimReel[:, [0, 1]],
                     SampleRef[:, [0, 1]],
                     nomVar=variable_names)

    print("▶ Trace Fenêtres globales")
    TraceFenetres(SimReel[:, [0, 1]], SampleRef[:, [0, 1]], N=300)

    print("▶ Trace Mensuel global")
    TraceMensuelFenetre(SimReel[:, [0, 1]], SampleRef[:, [0, 1]], fen=fen)

    print("Rapport terminé.")

def plot_scenarios_with_range(Y_true_full, scenarios_pred, start=0, end=1000):
    """
    Affiche une partie spécifique de la série réelle et des scénarios générés.
    
    Args:
        Y_true_full: Série réelle, shape (N, 2)
        scenarios_pred: Scénarios générés, shape (num_scenarios, N, 2)
        start: Index de début (inclus)
        end: Index de fin (exclu)
    """
    var_names = ["Wind Speed", "Wave Height"]

    for var_idx in range(2):
        plt.figure(figsize=(14, 5))

        # Série réelle sur la plage spécifiée
        plt.plot(range(start, end), Y_true_full[start:end, var_idx],
                 label="Réel", color="black", linewidth=2)

        # Scénarios sur la même plage
        for i in range(scenarios_pred.shape[0]):
            plt.plot(range(start, end), scenarios_pred[i, start:end, var_idx],
                     linestyle="--", alpha=0.4)

        plt.title(f"{var_names[var_idx]} – {scenarios_pred.shape[0]} scénarios [{start}:{end}]")
        plt.xlabel("Time step")
        plt.ylabel("Valeur normalisée")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

