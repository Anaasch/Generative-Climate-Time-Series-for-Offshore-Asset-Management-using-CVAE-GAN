import tensorflow as tf
from tensorflow.keras import layers, Model, Input # type: ignore
import numpy as np

# ============================================================
#  Layers utilitaires
# ============================================================

def build_dense_layers(x, nb_layers, units, activation):
    """
    Empile nb_layers de Dense(units) + activation.
    activation ∈ {'relu','tanh','leakyrelu'}.
    """
    for _ in range(nb_layers):
        x = layers.Dense(units)(x)
        if activation == 'leakyrelu':
            x = layers.LeakyReLU(negative_slope=0.2)(x)
        else:
            x = layers.Activation(activation)(x)
    return x

# ============================================================
#  Générateur (conditionnel) et Critique WGAN (conditionnel)
# ============================================================

def build_cgan_generator(nVar, Lag, LagO, seasonFreq,
                         z_dim=32, nb_layers=3, units=256, activation='leakyrelu'):
    """
    Inputs:
      - season_i: (2,)
      - lag_input: (nVar*Lag,)
      - z: (z_dim,)
    Output:
      - y_hat: (nVar*LagO,) dans [-1,1] (activation 'tanh')
    """
    n_season = len(seasonFreq)
    season_inputs = [Input(shape=(2,), name=f"G_season_input_{i}") for i in range(n_season)]
    lag_input = Input(shape=(nVar * Lag,), name="G_lag_input")
    z_input   = Input(shape=(z_dim,),     name="G_z_input")

    concat = layers.Concatenate(axis=-1)(season_inputs + [lag_input, z_input])
    x = build_dense_layers(concat, nb_layers=nb_layers, units=units, activation=activation)
    y_hat = layers.Dense(nVar * LagO, activation='tanh', name="G_out")(x)

    G = Model(inputs=season_inputs + [lag_input, z_input], outputs=y_hat, name="Generator")
    return G


def build_cgan_critic(nVar, Lag, LagO, seasonFreq,
                      nb_layers=3, units=256, activation='leakyrelu'):
    """
    Inputs:
      - season_i: (2,)
      - lag_input: (nVar*Lag,)
      - y: (nVar*LagO,)
    Output:
      - score: (1,) (sortie linéaire pour WGAN)
    """
    n_season = len(seasonFreq)
    season_inputs = [Input(shape=(2,), name=f"D_season_input_{i}") for i in range(n_season)]
    lag_input = Input(shape=(nVar * Lag,),    name="D_lag_input")
    y_input   = Input(shape=(nVar * LagO,),   name="D_y_input")

    concat = layers.Concatenate(axis=-1)(season_inputs + [lag_input, y_input])
    x = build_dense_layers(concat, nb_layers=nb_layers, units=units, activation=activation)
    score = layers.Dense(1, activation=None, name="D_out")(x)

    D = Model(inputs=season_inputs + [lag_input, y_input], outputs=score, name="Critic")
    return D


def build_generator_critic(nVar=2, Lag=8, LagO=47, seasonFreq=(24, 8760),
                           z_dim=32, nb_layers=3, units_gen=256, units_disc=256,
                           activation='leakyrelu'):
    G = build_cgan_generator(nVar, Lag, LagO, seasonFreq,
                             z_dim=z_dim, nb_layers=nb_layers, units=units_gen, activation=activation)
    D = build_cgan_critic(nVar, Lag, LagO, seasonFreq,
                          nb_layers=nb_layers, units=units_disc, activation=activation)
    return G, D

# ============================================================
#  Modèle entraînable WGAN-GP (subclassing, comme ton VAE)
# ============================================================

class CGAN_WGANGP(Model):
    """
    Modèle entraînable WGAN-GP conditionnel, compatible Keras .fit()
    Entrée data attendue dans train_step/test_step: (X, y_true)
      - X = [season_0, season_1, ..., lag_input, lagO_input] (on ignore lagO_input)
      - y_true = lagO_input (shape: (B, nVar*LagO))
    """
    def __init__(self, generator, critic, seasonFreq,
                 gp_weight=10.0, n_critic=5, l1_weight=10.0, z_dim=32, z_std=1.0):
        super().__init__()
        self.G = generator
        self.D = critic
        self.seasonFreq = seasonFreq
        self.n_season = len(seasonFreq)
        self.gp_weight = gp_weight
        self.n_critic = n_critic
        self.l1_weight = l1_weight
        self.z_dim = z_dim
        self.z_std = z_std

        # metrics
        self.d_loss_tracker = tf.keras.metrics.Mean(name="d_loss")
        self.g_loss_tracker = tf.keras.metrics.Mean(name="g_loss")
        self.l1_tracker     = tf.keras.metrics.Mean(name="l1_term")
        self.gp_tracker     = tf.keras.metrics.Mean(name="gp")

    @property
    def metrics(self):
        return [self.d_loss_tracker, self.g_loss_tracker, self.l1_tracker, self.gp_tracker]

    def compile(self, g_optimizer, d_optimizer):
        super().compile()
        self.g_optimizer = g_optimizer
        self.d_optimizer = d_optimizer

    # ---------- helpers ----------
    def _concat_condition(self, season_inputs, lag_input):
        # season_inputs: list of Tensors [(B,2), ...], lag_input: (B, nVar*Lag)
        return tf.concat(season_inputs + [lag_input], axis=-1)

    def _gradient_penalty(self, season_inputs, lag_input, real_y, fake_y):
        eps = tf.random.uniform(shape=(tf.shape(real_y)[0], 1), minval=0.0, maxval=1.0)
        inter = eps * real_y + (1.0 - eps) * fake_y
        with tf.GradientTape() as gp_tape:
            gp_tape.watch(inter)
            pred = self.D(season_inputs + [lag_input, inter], training=True)
        grads = gp_tape.gradient(pred, [inter])[0]
        norm = tf.sqrt(tf.reduce_sum(tf.square(grads), axis=1) + 1e-12)
        gp = tf.reduce_mean((norm - 1.0) ** 2)
        return gp

    # ---------- training ----------
    def train_step(self, data):
        # data: (X, y_true)
        X, y_true = data
        # X attendu: [season_0, season_1, ..., lag_input, lagO_input]
        season_inputs = [tf.cast(X[i], tf.float32) for i in range(self.n_season)]
        lag_input = tf.cast(X[self.n_season], tf.float32)
        y_true = tf.cast(y_true, tf.float32)  # (B, nVar*LagO)

        cond = self._concat_condition(season_inputs, lag_input)
        batch_size = tf.shape(cond)[0]

        # --- Update Critic n_critic fois ---
        d_losses = []
        gp_vals = []
        for _ in range(self.n_critic):
            z = tf.random.normal(shape=(batch_size, self.z_dim), mean=0.0, stddev=self.z_std)
            with tf.GradientTape() as tape:
                y_fake = self.G(season_inputs + [lag_input, z], training=True)
                d_real = self.D(season_inputs + [lag_input, y_true], training=True)
                d_fake = self.D(season_inputs + [lag_input, y_fake], training=True)
                # WGAN objective: minimise (E_fake - E_real)
                d_loss = tf.reduce_mean(d_fake) - tf.reduce_mean(d_real)
                gp = self._gradient_penalty(season_inputs, lag_input, y_true, y_fake) * self.gp_weight
                d_total = d_loss + gp
            grads = tape.gradient(d_total, self.D.trainable_variables)
            self.d_optimizer.apply_gradients(zip(grads, self.D.trainable_variables))
            d_losses.append(d_total)
            gp_vals.append(gp)

        # --- Update Generator ---
        z = tf.random.normal(shape=(batch_size, self.z_dim), mean=0.0, stddev=self.z_std)
        with tf.GradientTape() as tape:
            y_fake = self.G(season_inputs + [lag_input, z], training=True)
            d_fake = self.D(season_inputs + [lag_input, y_fake], training=False)
            g_loss = -tf.reduce_mean(d_fake)
            l1 = tf.reduce_mean(tf.abs(y_true - y_fake)) if self.l1_weight > 0.0 else 0.0
            g_total = g_loss + self.l1_weight * l1
        grads = tape.gradient(g_total, self.G.trainable_variables)
        self.g_optimizer.apply_gradients(zip(grads, self.G.trainable_variables))

        # metrics
        self.d_loss_tracker.update_state(tf.reduce_mean(d_losses))
        self.g_loss_tracker.update_state(g_loss)
        self.l1_tracker.update_state(l1 if isinstance(l1, tf.Tensor) else 0.0)
        self.gp_tracker.update_state(tf.reduce_mean(gp_vals))
        return {
            "d_loss": self.d_loss_tracker.result(),
            "g_loss": self.g_loss_tracker.result(),
            "l1_term": self.l1_tracker.result(),
            "gp": self.gp_tracker.result(),
        }

    def test_step(self, data):
        X, y_true = data
        season_inputs = [tf.cast(X[i], tf.float32) for i in range(self.n_season)]
        lag_input = tf.cast(X[self.n_season], tf.float32)
        y_true = tf.cast(y_true, tf.float32)

        batch_size = tf.shape(y_true)[0]
        z = tf.random.normal(shape=(batch_size, self.z_dim), mean=0.0, stddev=self.z_std)
        y_fake = self.G(season_inputs + [lag_input, z], training=False)
        d_real = self.D(season_inputs + [lag_input, y_true], training=False)
        d_fake = self.D(season_inputs + [lag_input, y_fake], training=False)
        d_loss = tf.reduce_mean(d_fake) - tf.reduce_mean(d_real)
        l1 = tf.reduce_mean(tf.abs(y_true - y_fake)) if self.l1_weight > 0.0 else 0.0
        g_loss = -tf.reduce_mean(d_fake) + self.l1_weight * l1

        self.d_loss_tracker.update_state(d_loss)
        self.g_loss_tracker.update_state(g_loss)
        self.l1_tracker.update_state(l1 if isinstance(l1, tf.Tensor) else 0.0)
        # pas de GP en validation
        return {"d_loss": self.d_loss_tracker.result(),
                "g_loss": self.g_loss_tracker.result(),
                "l1_term": self.l1_tracker.result()}

    # ---------- Inférence pratique (multi-échantillons) ----------
    @tf.function
    def sample_forecast(self, season_inputs, lag_input, n_samples=1, z_std=1.0):
        """
        season_inputs: liste de T tensors (B,2), lag_input: (B, nVar*Lag)
        Retourne: (n_samples, B, nVar*LagO)
        """
        batch = tf.shape(lag_input)[0]
        latent_dim = self.z_dim # = z_dim
        outputs = []
        for _ in range(n_samples):
            z = tf.random.normal(shape=(batch, latent_dim), stddev=z_std)
            y_hat = self.G(season_inputs + [lag_input, z], training=False)
            outputs.append(y_hat)
        return tf.stack(outputs, axis=0)

# ============================================================
#  Optimiseurs utilitaires (comme dans vae_model.py)
# ============================================================

def get_optimizer(name='adam', learning_rate=1e-4, beta_1=0.5, beta_2=0.9):
    name = name.lower()
    if name == 'adam':
        return tf.keras.optimizers.Adam(learning_rate=learning_rate, beta_1=beta_1, beta_2=beta_2)
    elif name == 'rmsprop':
        return tf.keras.optimizers.RMSprop(learning_rate=learning_rate)
    elif name == 'sgd':
        return tf.keras.optimizers.SGD(learning_rate=learning_rate, momentum=0.0)
    else:
        raise ValueError(f"Optimiseur '{name}' non supporté")

# ============================================================
#  Entraînement (API similaire à train_vae_with_params)
# ============================================================

def train_gan_with_params(X_train, Y_train, X_test, Y_test, params):
    """
    params attendus:
      - nVar, Lag, LagO, seasonFreq
      - z_dim, nb_layers, activation, units_gen, units_disc
      - gp_weight, n_critic, l1_weight
      - g_optimizer_name, d_optimizer_name, lr_g, lr_d
      - epochs, batch_size
    """
    print(f"Training GAN with params: {params}")

    nVar        = params.get('nVar', 2)
    Lag         = params.get('Lag', 8)
    LagO        = params.get('LagO', 47)
    seasonFreq  = tuple(params.get('seasonFreq', (24, 8760)))
    z_dim       = params.get('z_dim', 32)
    nb_layers   = params.get('nb_layers', 3)
    activation  = params.get('activation', 'leakyrelu')
    units_gen   = params.get('units_gen', 256)
    units_disc  = params.get('units_disc', 256)
    gp_weight   = params.get('gp_weight', 10.0)
    n_critic    = params.get('n_critic', 5)
    l1_weight   = params.get('l1_weight', 10.0)
    epochs      = params.get('epochs', 50)
    batch_size  = params.get('batch_size', 128)
    g_opt_name  = params.get('g_optimizer_name', 'adam')
    d_opt_name  = params.get('d_optimizer_name', 'adam')
    lr_g        = params.get('lr_g', 1e-4)
    lr_d        = params.get('lr_d', 1e-4)
    beta_1      = params.get('beta_1', 0.5)  # usuel pour GAN
    beta_2      = params.get('beta_2', 0.9)

    G, D = build_generator_critic(
        nVar=nVar, Lag=Lag, LagO=LagO, seasonFreq=seasonFreq,
        z_dim=z_dim, nb_layers=nb_layers,
        units_gen=units_gen, units_disc=units_disc,
        activation=activation
    )

    gan = CGAN_WGANGP(
        generator=G, critic=D, seasonFreq=seasonFreq,
        gp_weight=gp_weight, n_critic=n_critic,
        l1_weight=l1_weight, z_dim=z_dim, z_std=1.0
    )

    g_opt = get_optimizer(g_opt_name, learning_rate=lr_g, beta_1=beta_1, beta_2=beta_2)
    d_opt = get_optimizer(d_opt_name, learning_rate=lr_d, beta_1=beta_1, beta_2=beta_2)
    gan.compile(g_optimizer=g_opt, d_optimizer=d_opt)

    # Entraînement direct avec la même interface que pour le VAE:
    # x = X_train (liste [season_0, season_1, ..., lag_input, lagO_input])
    # y = Y_train (targets = lagO_input)
    history = gan.fit(
        x=X_train, y=Y_train,
        validation_data=(X_test, Y_test),
        epochs=epochs, batch_size=batch_size,
        verbose=2
    )
    return gan, history
