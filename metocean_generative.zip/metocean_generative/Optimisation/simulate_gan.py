import numpy as np
import tensorflow as tf

def SimuleTS(
    gan_model,
    X_input,
    seasonFreq,
    Min_list,
    Max_list,
    nVar,
    GAUSSIAN_STD=1.0,
    random_seed=None
):
    """
    Simule toute la série temporelle à partir d'une seule instance initiale (GAN).

    Args:
        gan_model: modèle GAN entraîné (CGAN_WGANGP)
        X_input: liste des entrées [season_0, season_1, lag_input, lagO_input]
        seasonFreq: fréquences saisonnières (cos/sin)
        Min_list, Max_list: min et max par variable pour dénormalisation
        nVar: nombre de variables (ex : 2 pour vent & vague)
        GAUSSIAN_STD: écart-type pour le bruit latent
        random_seed: (optionnel) int pour fixer la graine aléatoire

    Returns:
        Sim_real: simulation dénormalisée (shape: (T_total, nVar))
        Sim_norm: simulation normalisée [-1,1] (shape: (T_total, nVar))
    """
    if random_seed is None:
        random_seed = 123456

    tf.random.set_seed(random_seed)
    season_inputs = X_input[:len(seasonFreq)]
    lag_input_init = X_input[len(seasonFreq)][0]  # (nVar * Lag,)
    lagO_input = X_input[len(seasonFreq) + 1]

    Lag = lag_input_init.shape[0] // nVar
    LagO = lagO_input.shape[1] // nVar if len(lagO_input.shape) > 1 else lagO_input.shape[0] // nVar
    T_total = season_inputs[0].shape[0]

    lag_input = lag_input_init.copy()
    Sim_norm = []

    t = 0
    while t < T_total:
        season_t = [tf.expand_dims(tf.convert_to_tensor(season_inputs[i][t]), axis=0)
                    for i in range(len(seasonFreq))]
        lag_tensor = tf.expand_dims(tf.convert_to_tensor(lag_input, dtype=tf.float32), axis=0)

        y_pred = gan_model.sample_forecast(season_t, lag_tensor, n_samples=1, z_std=GAUSSIAN_STD)[0].numpy()
        y_pred = y_pred.reshape(LagO, nVar)
        Sim_norm.append(y_pred)

        # Mise à jour du lag_input
        pred_flat = y_pred.flatten()
        expected_len = nVar * Lag
        if pred_flat.shape[0] >= expected_len:
            lag_input[-expected_len:] = pred_flat[-expected_len:]
        else:
            padding = np.zeros(expected_len - pred_flat.shape[0])
            lag_input[-expected_len:] = np.concatenate([pred_flat, padding])

        t += LagO

    Sim_norm = np.vstack(Sim_norm)[:T_total]

    Sim_real = np.empty_like(Sim_norm)
    for i in range(nVar):
        Sim_real[:, i] = 0.5 * (Sim_norm[:, i] + 1) * (Max_list[i] - Min_list[i]) + Min_list[i]

    return Sim_real, Sim_norm