import sys
import os
import traceback

# --- Déterminisme & hash ---
os.environ['PYTHONHASHSEED'] = '42'        # hash Python stable
os.environ['TF_DETERMINISTIC_OPS'] = '1'   # kernels TF déterministes quand c'est possible


# Supprimer les logs TensorFlow sur la sortie standard
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import tensorflow as tf
tf.get_logger().setLevel('ERROR')

from data_preparation import load_and_prepare_data
from vae_model import train_vae_with_params
from custom_score import evaluate_multiple_scenarios

import random
import numpy as np


SEED = 42  # <- choisis ta graine

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)


def evaluate_model(params):
    try:
        X_train, Y_train, X_test, Y_test, Min_list, Max_list, fen = load_and_prepare_data(
            lag=params["Lag"], lag0=params["LagO"]
        )

        vae_model, _ = train_vae_with_params(
            X_train, Y_train,
            X_test, Y_test,
            params
        )

        df_scores = evaluate_multiple_scenarios(
            vae_model=vae_model,
            X_input_test=X_test,
            Y_target_test=Y_test,
            seasonFreq=params['seasonFreq'],
            Min_list=Min_list,
            Max_list=Max_list,
            nVar=params['nVar'],
            fen=fen,
            n_scenarios=1,
            GAUSSIAN_STD=1.0
        )

        if "score_global" not in df_scores.columns or df_scores["score_global"].empty:
            raise ValueError("score_global missing or empty in df_scores")

        mean_score = df_scores["score_global"].mean()

        if not np.isfinite(mean_score):
            raise ValueError("mean_score is not finite")
        
        obj = -mean_score  # NOMAD minimise

  
    except Exception as e:
        with open("debug_args.log", "a") as f:
            f.write(f"Exception in evaluate_model: {str(e)}\n")
            f.write(traceback.format_exc())
            f.write("Params: " + str(params) + "\n")

        obj = 1e6  # pénalité forte

    return obj 

if __name__ == "__main__":
    if len(sys.argv) != 12:
        print(1e6)
        sys.exit(0)

    try:
        beta           = float(sys.argv[1])
        latent_dim     = int(round(float(sys.argv[2])))
        nb_layers      = int(round(float(sys.argv[3])))
        activation_idx = int(round(float(sys.argv[4])))
        opti_idx       = int(round(float(sys.argv[5])))
        log_lr         = float(sys.argv[6])
        learning_rate  = 10 ** log_lr
        units_encoder  = int(round(float(sys.argv[7])))
        units_decoder  = int(round(float(sys.argv[8])))
        batch_size     = int(round(float(sys.argv[9])))
        Lag            = int(round(float(sys.argv[10])))
        LagO           = int(round(float(sys.argv[11])))

    except Exception as e:
        with open("debug_args.log", "a") as f:
           f.write(f"Exception parsing args: {str(e)}\n")
           f.write(traceback.format_exc())
           f.write("Arguments reçus : " + str(sys.argv) + "\n")

        print(1e6)
        sys.exit(0)

    activation_list = ['relu', 'tanh', 'leakyrelu']
    optimizer_list = ['adam', 'rmsprop', 'sgd']

    activation = activation_list[activation_idx] if 0 <= activation_idx < len(activation_list) else 'relu'
    optimizer_name = optimizer_list[opti_idx] if 0 <= opti_idx < len(optimizer_list) else 'adam'

    params = {
        "beta_max": beta,
        "latent_dim": latent_dim,
        "nb_layers": nb_layers,
        "activation": activation,
        "optimizer_name": optimizer_name,
        "learning_rate": learning_rate,
        "units_encoder": units_encoder,
        "units_decoder": units_decoder,
        "batch_size": batch_size,
        "epochs": 40,
        "beta_warmup_epochs": 5,
        "beta_cyclical": False,
        "seasonFreq": [24, 8760],
        "nVar": 2,
        "Lag": Lag,
        "LagO": LagO
    }

    score = evaluate_model(params)

    if not isinstance(score, (float, int)) or score != score or score == float('inf') or score == float('-inf'):
        score = 1e6

    try:
        with open("log_nomad_results.csv", "a") as f:
            f.write(f"{beta},{latent_dim},{nb_layers},{activation},{optimizer_name},{learning_rate},{units_encoder},{units_decoder},{batch_size},{Lag},{LagO},{score}\n")
    except Exception as e:
        with open("debug_args.log", "a") as f:
            f.write(f"Exception writing log: {str(e)}\n")

    print(score)
    sys.stdout.flush()