import sys
import os
import random
import numpy as np
import tensorflow as tf
import traceback

# -----------------------------
# Réglages TensorFlow et seed
# -----------------------------
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
tf.get_logger().setLevel('ERROR')

# Seed pour reproductibilité
seed_value = 42
os.environ['PYTHONHASHSEED'] = str(seed_value)
random.seed(seed_value)
np.random.seed(seed_value)
tf.random.set_seed(seed_value)

# -----------------------------
# Imports de ton projet
# -----------------------------
from data_preparation import load_and_prepare_data
from vae_model import train_vae_with_params
from custom_score import evaluate_multiple_scenarios

# -----------------------------
# Paramètres
# -----------------------------
params = {
    "beta_max": 5e-5,
    "latent_dim": 10,
    "nb_layers": 2,
    "activation": 'relu',
    "optimizer_name": 'adam',
    "learning_rate": 0.001,
    "units_encoder": 64,
    "units_decoder": 94,
    "batch_size": 68,
    "epochs": 40,
    "beta_warmup_epochs": 5,
    "beta_cyclical": False,
    "seasonFreq": [24, 8760],
    "nVar": 2,
    "Lag": 4,
    "LagO": 44
}

try:
    # -----------------------------
    # Chargement des données
    # -----------------------------
    X_train, Y_train, X_test, Y_test, Min_list, Max_list, fen = load_and_prepare_data(
        lag=params["Lag"], lag0=params["LagO"]
    )

    # -----------------------------
    # Entraînement VAE
    # -----------------------------
    vae_model, _ = train_vae_with_params(
        X_train, Y_train,
        X_test, Y_test,
        params
    )

    # -----------------------------
    # Sauvegarde du modèle
    # -----------------------------
    model_path = "vae_model_saved.h5"
    vae_model.save(model_path)
    print(f"Model saved at {model_path}")

    # -----------------------------
    # Évaluation
    # -----------------------------
    df_scores = evaluate_multiple_scenarios(
        vae_model=vae_model,
        X_input_test=X_test,
        Y_target_test=Y_test,
        seasonFreq=params['seasonFreq'],
        Min_list=Min_list,
        Max_list=Max_list,
        nVar=params['nVar'],
        fen=fen,
        n_scenarios=1,
        GAUSSIAN_STD=1.0
    )

    print("Training and evaluation completed successfully.")
    if "score_global" in df_scores.columns:
        print("Mean score_global:", df_scores["score_global"].mean())

except Exception as e:
    with open("debug_train.log", "a") as f:
        f.write("Exception during training:\n")
        f.write(traceback.format_exc())
    print("An error occurred. Check debug_train.log for details.")
