import numpy as np

def load_and_prepare_data(lag=8, lag0=47, fixed_slicing=False):
    file_paths = [
        r'C:\Users\d72085\Downloads\Wind_Fecamp.txt',
        r'C:\Users\d72085\Downloads\Wave_Fecamp.txt'
    ]
    nVar = len(file_paths)
    seasonFreq = np.array([24, 8760])

    series_list = []
    Min_list = []
    Max_list = []

    S = np.inf  # Longueur minimale

    for file in file_paths:
        with open(file, 'r') as f:
            lines = f.readlines()

        # Trouver index première ligne valide (nombre)
        start_index = 0
        for i, line in enumerate(lines):
            first_token = line.strip().split()[0] if line.strip().split() else ""
            try:
                float(first_token)
                start_index = i
                break
            except ValueError:
                continue

        data = np.loadtxt(lines[start_index:])

        if data.ndim == 2 and data.shape[1] == 1:
            data = data.flatten()

        series_list.append(data)
        S = min(S, len(data))

    series_list = [serie[:S] for serie in series_list]

    # Median for fen
    Y_stack = np.vstack(series_list).T  # shape (S, nVar)
    fen = np.median(Y_stack, axis=0)

    normalized_series_list = []

    for serie in series_list:
        min_val = np.min(serie)
        max_val = np.max(serie)
        Min_list.append(min_val)
        Max_list.append(max_val)

        serie_norm = 2 * (serie - min_val) / (max_val - min_val) - 1
        normalized_series_list.append(serie_norm)

    # Build fused series: first of each, second of each...
    Sample = []
    for i in range(S):
        for serie_norm in normalized_series_list:
            Sample.append(serie_norm[i])
    Sample = np.array(Sample)

    InputG = []

    # 1. Seasonal components
    t = np.arange(1, S - lag * nVar - lag0 * nVar + 1)
    for freq in seasonFreq:
        cos_component = np.cos(2 * np.pi * t / freq)
        sin_component = np.sin(2 * np.pi * t / freq)
        InputG.append(np.vstack([cos_component, sin_component]))  # (2, T)

    # 2. Short lag input
    lag_input = []
    vec_size = lag * nVar
    for k in range(1, S - lag * nVar - lag0 * nVar + 1):
        idx = (k - 1) * nVar
        vec = Sample[idx:idx + vec_size]
        lag_input.append(vec)
    InputG.append(np.array(lag_input).T)  # (lag * nVar, T)

    # 3. Long lag input
    lagO_input = []
    vec_size = lag0 * nVar
    for k in range(1, S - lag0 * nVar - lag * nVar + 1):
        idx = (k - 1) * nVar + lag * nVar
        vec = Sample[idx:idx + vec_size]
        lagO_input.append(vec)
    InputG.append(np.array(lagO_input).T)  # (lag0 * nVar, T)

    # Final concat along features axis (rows)
    X = np.concatenate(InputG, axis=0)  # (total_features, time)

    if fixed_slicing:
        # découpage fixe comme dans ton code initial
        season_input_0 = X[0:2, :].T
        season_input_1 = X[2:4, :].T
        lag_input = X[4:20, :].T
        lagO_input = X[20:, :].T
    else:
        # découpage dynamique selon lag et lag0
        idx = 0
        season_input_0 = X[idx:idx+2, :].T
        idx += 2
        season_input_1 = X[idx:idx+2, :].T
        idx += 2
        lag_input = X[idx:idx + lag * nVar, :].T
        idx += lag * nVar
        lagO_input = X[idx:idx + lag0 * nVar, :].T

    X_input = [season_input_0, season_input_1, lag_input, lagO_input]
    Y_target = lagO_input.copy()

    # Train/Test split
    split_ratio = 0.8
    N = X_input[0].shape[0]
    split_index = int(N * split_ratio)

    X_input_train = [x[:split_index] for x in X_input]
    X_input_test = [x[split_index:] for x in X_input]

    Y_target_train = Y_target[:split_index]
    Y_target_test = Y_target[split_index:]

    return X_input_train, Y_target_train, X_input_test, Y_target_test, Min_list, Max_list, fen


if __name__ == "__main__":
    # Exemple de test avec lag et lag0 modifiables
    X_train, Y_train, X_test, Y_test, mins, maxs, fen = load_and_prepare_data(lag=8, lag0=47)
    print(f"Train input shapes: {[x.shape for x in X_train]}")
    print(f"Train target shape: {Y_train.shape}")
    print(f"Test input shapes: {[x.shape for x in X_test]}")
    print(f"Test target shape: {Y_test.shape}")
